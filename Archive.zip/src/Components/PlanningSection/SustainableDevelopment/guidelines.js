const guidelines = [
        "Promote Ecotourism",
        "Support Local Communities",
        "Protect Cultural Heritage",
        "Sustainable Infrastructure",
        "Education and Awareness",
        "Responsible Wildlife Tourism",
    ]
    
export default guidelines;