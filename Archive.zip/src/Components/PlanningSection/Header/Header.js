import React, { useState } from "react";
import './Style.css';
import allCities from "./citiesNames";

const Header = () => {
	return (
		<React.Fragment>
			<div className="hero-section" id="locations">
			</div>
		</React.Fragment>
	);
}

export default Header;