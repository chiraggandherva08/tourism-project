import React, { useTransition } from "react";
import './Style.css';

const TransportData = () => {
    return (
        <React.Fragment>
            {
                <div className="airplane">
                </div>
            }
        </React.Fragment>
    );
}

export default TransportData;