1. Displaying railways timings to the destination if available.
2. We can create a feature listing top ranked hotels that can be filtered near the destination.
3. Listing cultural heritage sites.
4. integrating google maps.
5. Weather forcastings(for next few days).
6. Sustainable practices.
7. Language barriers.
8. Listing Wifi passwords.
9. Hospital.